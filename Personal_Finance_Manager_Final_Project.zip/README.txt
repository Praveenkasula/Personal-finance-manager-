PERSONAL FINANCE MANAGER - STARTER SOURCE PROJECT
=================================================

This is a starter Android WebView project with a local finance tracker UI.
It is NOT a finished or security-audited banking application and no APK has
been built or tested in this package.

Implemented in this starter:
- Dashboard totals and recent transactions
- Add income and expense entries
- Multiple account labels (Bank/Cash/UPI/Credit Card)
- Light/Dark theme
- English/Telugu labels for main dashboard areas
- JSON export/import
- CSV export (Excel-compatible)
- Android screenshot/recents protection flag
- Biometric/device-credential prompt hook
- EncryptedSharedPreferences hook for future PIN state

Not implemented yet:
- Encrypted transaction database (current prototype uses WebView localStorage)
- Complete PIN enrollment/change/reset flow
- Password-encrypted backup
- PDF export
- Bank SMS reading/import and confirmation flow
- Account balance reconciliation, transfers, EMI, budgets, credit-card bills
- Full Telugu translation of every screen
- Security audit and device compatibility testing

IMPORTANT SECURITY NOTE:
Do not enter real bank credentials, UPI PINs, OTPs, or highly sensitive financial
information into this starter prototype. The transaction store is not encrypted.
The Android biometric code is only a starter gate and must be completed and tested
before treating the app as protected.

Build:
- Open this folder in Android Studio.
- Use JDK 17 and Android Gradle Plugin 8.7.3.
- Build > Build Bundle(s) / APK(s) > Build APK(s).
- Verify all dependencies resolve and test on a device before use.

The project requires internet for the initial Gradle dependency download.
